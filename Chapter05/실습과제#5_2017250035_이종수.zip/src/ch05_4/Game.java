package ch05_4;

public class Game {
    private String hands;

   public void setHands(String hands){
       this.hands = hands;
    }
    public String getHands(){
       return hands;
    }

}
