package s;

public class Rectangle {
}
