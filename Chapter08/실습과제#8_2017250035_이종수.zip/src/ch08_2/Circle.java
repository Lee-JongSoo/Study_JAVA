package ch08_2;

public class Circle extends Shape{
    public Circle(int width, int height) {
        super(width, height);
    }
}
