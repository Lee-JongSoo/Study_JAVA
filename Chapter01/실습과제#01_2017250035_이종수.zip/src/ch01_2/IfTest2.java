package ch01_2;

public class IfTest2 {
    public static void main(String[] args){
        int x = 2;
        if(x==3){
            System.out.println("x must be 3");
        }else{
            System.out.println("X is NOT 3");
        }
        System.out.println("This runs no matter what");
        System.out.println();
        System.out.println("by 2017250035 이종수");
    }
}
