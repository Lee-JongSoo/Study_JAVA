package ch02_2;

public class GameLauncher {
    public static void main(String[] args){
        GuessGame game = new GuessGame();
        game.startGame();
        System.out.println();
        System.out.println("by 2017250035 이종수");
    }
}
